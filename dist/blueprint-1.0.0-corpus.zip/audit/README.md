# Negativbeweise

Dieses Verzeichnis zeigt, dass das Paket sich selbst widerlegen kann. Jeder
Fall ist genau ein Defekt; die Prüfung muss ihn mit den genannten Codes und
Exit 1 ablehnen. Die Rezepte und Erwartungen reisen mit dem Archiv, die
Prüfung selbst liegt im Quell-Repo.

## Selbst prüfen (ohne Repo)

Der Prüfer reist mit: `audit/scripts/blueprint-verify.mjs` und sein Import-
Abschluss unter `audit/ui/blueprint/` sind byte-identisch zu den Repo-Modulen.

```sh
node audit/scripts/blueprint-verify.mjs .
```

## Einen Defekt nachstellen

```sh
node audit/mutate.mjs . selector-unresolved ../defekt-kopie
node audit/scripts/blueprint-verify.mjs ../defekt-kopie
```

Der Mutator kopiert das Paket, ändert eine Stelle und siegelt
`MANIFEST.json` neu — außer beim Fall `manifest-entry-digest`, der genau
diese Siegelung bricht. Exit 0 der Prüfung heißt: das Paket ist unverändert
gültig; jede Mutation endet mit Exit 1.

## Fälle

| Fall | Defekt | Erwartete Codes |
| --- | --- | --- |
| `selector-unresolved` | Ein Claim belegt sich mit einem DOM-Selektor, der im Paket auf keinen Knoten zeigt. | `claim.evidence.selector_unresolved` |
| `ledger-missing` | Eine gedeckte Ledger-Einheit fehlt; der Nenner bleibt unverändert. | `ledger.denominator.mismatch`, `ledger.unit.missing` |
| `ledger-extra` | Eine zusätzliche Ledger-Einheit taucht auf, ohne den Nenner zu erhöhen. | `ledger.denominator.mismatch`, `ledger.unit.unexpected` |
| `ledger-reclassify` | Die Gesamtzahl bleibt, aber eine Einheit wechselt die Nenner-Kategorie. | `ledger.denominator.mismatch`, `ledger.unit.reclassified` |
| `docs-ceiling` | BLUEPRINT.md nennt eine andere Evidenz-Decke als das Manifest. | `docs.ceiling.mismatch`, `render.not_deterministic` |
| `docs-claim-count` | BLUEPRINT.md zählt einen Claim mehr, als das Paket führt. | `docs.claim_count.mismatch`, `render.not_deterministic` |
| `manifest-entry-digest` | Ein Datei-Hash im Manifest passt nicht mehr zu den gepackten Bytes. | `manifest.hash_mismatch` |
