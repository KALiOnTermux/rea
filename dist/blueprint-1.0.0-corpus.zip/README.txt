REA Studio — Blaupause

BLUEPRINT.md      Der vollständige Bauplan (zuerst lesen).
AGENT-PROMPT.md   Fertiger Auftrag zum Kopieren in einen Coding-Agenten.
blueprint.json    Dieselben Fakten maschinenlesbar.
ledger.json       Abschluss-Ledger: Nenner, Einträge, Coverage.
acceptance.json   Ausführbare Abnahmeprüfungen (http, dom, structure, …).
MANIFEST.json     Jede Datei mit Größe und SHA-256.
schemas/          JSON-Schemas für Behauptungen, Ledger, Manifest und Flows.
flows/            Aufgenommene Abläufe als JSON (Schritt, Ziel, Beleg).
specs/            UI- und Logik-Spec für den Nachbau.
audit/            Selbstprüfung: Paket-Prüfer, Mutator und erwartete Gate-Codes.
evidence/         Aufnahmen, Analysen und Werkzeugergebnisse.
source/           Exportierte Skripte oder dekompilierter Code.
surface/          DOM, Screenshot, Manifest, Ressourcen.

Behauptungen stehen in BLUEPRINT.md, Abschnitt 5-7; Abnahmekriterien in Abschnitt 8, offene Punkte in Abschnitt 9.

Grenzen dieses Pakets
Dieses Archiv ist aus dem committeten Corpus-Fixture gebaut; die dort
ausgewiesenen Lücken stehen in BLUEPRINT.md, Abschnitt 9, und in blueprint.json.
Der ursprüngliche 22-Claim-Capture ist nicht im Repository erhalten (er lag nur
im gitignorierten dist/) und deshalb nicht Teil dieses Archivs.