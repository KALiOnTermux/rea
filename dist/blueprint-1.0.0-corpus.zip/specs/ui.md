# UI-Spec — Shop

Diese Datei beschreibt die sichtbare Schale so, wie sie beobachtet wurde. Sie ersetzt keine Behauptung aus `BLUEPRINT.md`, sondern ordnet dieselben Fakten für den Nachbau.

## Rahmen

- **Titel:** Shop
- **Start-URL:** https://shop.test/
- **End-URL:** https://shop.test/
- **Sprache:** de
- **Ceiling:** executed
- **Beleg:** `evidence/web-capture.json`, `surface/dom.html`

## Struktur

| Element | Anzahl |
| --- | --- |
| article | 0 |
| aside | 0 |
| dialog | 0 |
| footer | 0 |
| form | 0 |
| header | 0 |
| main | 1 |
| nav | 0 |
| section | 0 |

## Überschriften

| Überschrift |
| --- |
| # Shop |

## Bedienelemente

| Label | ID | Typ | Selektor |
| --- | --- | --- | --- |
| Kaufen | #buy | button | #buy |

## Links

| Label | Ziel | Selektor |
| --- | --- | --- |
| Bestellungen | /orders | a[href="/orders"] |

## Abnahme

Die ausführbaren Prüfungen stehen in `acceptance.json`; die Kriterien und ihre Falsifier in `BLUEPRINT.md`, Abschnitt 8.
