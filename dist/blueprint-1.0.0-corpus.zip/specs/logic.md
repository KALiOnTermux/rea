# Logik-Spec — Shop

Diese Datei ordnet die beobachteten und abgeleiteten Logikfakten für den Nachbau. Belege stehen in `evidence/`, die Behauptungen samt Ceiling in `BLUEPRINT.md`, Abschnitt 5–7.

## Netzwerk

| Methode | URL | Status | Typ |
| --- | --- | --- | --- |
| GET | https://shop.test/api/orders | 200 | fetch |

## Routen

- `GET https://shop.test/` (aufgenommen)

## Daten

- `storage_keys`

## Abnahme

Die Prüfungen zu diesen Fakten stehen in `acceptance.json`; die Falsifier nennt `BLUEPRINT.md`, Abschnitt 10.

Der Rebuild liefert `surface/storage.json` mit den beobachteten Speicherschlüsseln; wurde nichts beobachtet, steht dort `observed: false` mit Begründung. Der Struktur-Check des Storage-Kriteriums prüft genau diese Datei.
