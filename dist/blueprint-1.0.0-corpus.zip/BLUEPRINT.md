# Blaupause: Shop

> Erstellt mit REA Studio aus dem ausgelieferten Ziel. Diese Blaupause trennt belegte Beobachtungen, abgeleitete Zusammenhänge und offene Punkte. Sie ist als Bauauftrag von Anfang bis Ende geschrieben.

## Kurzfassung

- **Ziel:** web · https://shop.test/
- **Belegt:** DOM und sichtbare Oberfläche, Netzwerk und Events
- **Offene Punkte:** 3
- **Enthaltene Beweise:** 4 Datei(en), 2111 Bytes vor Kompression
- **Evidenz-Decke:** executed
- **Herabstufungen:** keine
- **Behauptungen:** 16 gesamt · 6 observed · 7 derived · 3 assumed

## 1. Auftrag und Zielbild

Baue das Ziel von Anfang bis Ende neu auf: zuerst die äußere Form, dann das Verhalten, dann das Innenleben. Die Reihenfolge ist bewusst positiv herum. Beginne nicht mit dem Dekompilat, sondern mit einem lauffähigen Gerüst, das anschließend Schicht für Schicht mit den belegten Fakten gefüllt wird.

Die Blaupause beschreibt keine Vermutungen als Tatsachen. Wo etwas nur statisch abgeleitet oder gar nicht beobachtet wurde, steht das ausdrücklich in Abschnitt 9. Ein Coding-Agent soll diese Punkte zuerst prüfen, nicht stillschweigend erfinden.


### Reihenfolge des Aufbaus (verbindlich)

### Schritt 1: Projektgerüst und Laufzeit anlegen

Ein lauffähiges Grundprojekt mit derselben Auslieferungsform wie die Vorlage erstellen.

- **Eingaben:** surface/dom.html, behavior.network, evidence/web-analysis.json
- **Ergebnis:** Projektdateien, Start- und Build-Skript, lokaler Entwicklungsserver
- **Prüfung:** Build läuft fehlerfrei; Startseite antwortet mit HTTP 200

### Schritt 2: Oberfläche und Designsystem nachbauen

Landmarks, Überschriften, Navigation, Buttons, Formulare und Assets aus dem DOM übernehmen.

- **Eingaben:** surface/dom.html, surface/accessibility.txt, surface/screenshot.png
- **Ergebnis:** Layout, Komponenten, Stylesheets, Assets
- **Prüfung:** Alle im DOM gefundenen Bedienelemente sind vorhanden; Screenshot und Accessibility-Baum wirken gleichwertig

### Schritt 3: Routen und Seitenzustände implementieren

Die belegten Navigationsziele und Routen als echte Seiten abbilden.

- **Eingaben:** internals.routes, behavior.navigation
- **Ergebnis:** Router, Seitenkomponenten
- **Prüfung:** Jede Route rendert; Direkter Aufruf einer Route funktioniert

### Schritt 4: API- und Datenzugriff aufbauen

Die beobachteten Endpunkte mit denselben Methoden und Nutzlastformen anbinden.

- **Eingaben:** behavior.network.endpoints, behavior.network.requests
- **Ergebnis:** API-Client, Typen, Fehlerbehandlung
- **Prüfung:** Requests stimmen mit der Aufnahme überein; Lade-, Fehler- und Leerzustände sind sichtbar

### Schritt 5: Interaktionen, Events und Speicher übernehmen

Klicks, Formulare und Zustandswechsel so verbinden, dass dieselben Folge-Requests und Speicherungen entstehen.

- **Eingaben:** behavior.steps, behavior.events, surface.storage
- **Ergebnis:** Event-Handler, Zustandsverwaltung, Storage-Zugriffe
- **Prüfung:** Klickfolge erzeugt dieselben Requests; Storage-Schlüssel und Wertebereiche stimmen überein

### Schritt 6: Statische JavaScript-Funktionen und Aufrufe nachziehen

Die im Analysegraph belegten Funktionen, Module und Aufrufbeziehungen in die neue Struktur übertragen.

- **Eingaben:** evidence/web-analysis.json, source/web/
- **Ergebnis:** Module, Funktionen, Tests
- **Prüfung:** Relevante Funktionen sind vorhanden; Keine unaufgelösten Importe

### Schritt 7: Abgleich mit der Vorlage

Die rekonstruierte Anwendung gegen DOM, Netzwerk und Speicher der Aufnahme prüfen.

- **Eingaben:** alle vorherigen Schritte
- **Ergebnis:** Abgleichsbericht, Restliste
- **Prüfung:** DOM-Struktur gleichwertig; Netzwerkverhalten gleichwertig; Keine neuen Konsolenfehler


## 2. Ziel

- **Zieltyp:** web · web
- **Quelle:** https://shop.test/
- **Ceiling:** executed
- **Gate:** pass · partial · 0 Verletzung(en) · Coverage 0.7222
- **Closure:** 13 covered, 5 gap, 0 out_of_scope · Nenner 18 · Ratio 0.7222
- **Belegt:** DOM und sichtbare Oberfläche, Netzwerk und Events
- **Belege im Paket:** 4 Datei(en)

## 3. Oberfläche (äußere Schale)

- **Titel:** Shop
- **Start-URL:** https://shop.test/
- **End-URL:** https://shop.test/
- **Sprache:** de
- **DOM:** 174 Bytes, kein Screenshot
- **Accessibility:** nicht beigelegt

### Struktur

- main: 1

### Überschriften

- # Shop

### Bedienelemente

- Kaufen (#buy) [button]

### Links

- Bestellungen → `/orders`

### Sichtbarer Text (Auszug)

> Shop Kaufen Bestellungen

## 4. Verhalten

- **Aufgenommene Schritte:** 1
- **Netzwerk-Transaktionen:** 1, fehlgeschlagen: 0
- **Events:** 2 behalten, 0 verworfen

### Ablauf

- goto → https://shop.test/ (200, 12 ms)

### Navigationsziele

- `https://shop.test/`

### Beobachtete Endpunkte

- GET https://shop.test/api/orders (1×)

### Requests in Reihenfolge

- `GET` `https://shop.test/api/orders` → 200 [fetch]

### Events nach Art

- request: 1
- response: 1

### Innenleben

- **JavaScript-Dateien:** unbekannt, relevante Dateien: unbekannt, AST-Knoten: unbekannt
- **Semantischer Graph:** 0 Knoten, 0 Beziehungen
- **Anwendungsgraph:** 0 Knoten, 0 Kanten
- **Routen-Kandidaten:** 0

### Knotenarten


### Daten und Speicher

Es wurde kein Speicherzustand aufgenommen.

## 5. Beobachtet (observed)

Vom Lauf aufgezeichnete Fakten. Jede Aussage nennt die Belegdatei, ihre Position und den Test, der sie widerlegen würde.

### `web.dom-node.button-buy`

button#buy ist im aufgenommenen DOM vorhanden.

- **Ceiling:** executed
- **Subjekt:** `/surface/buttons/0`
- **Beleg:** `surface/dom.html`
- **Falsifier:** `acceptance.web.dom-node.button-buy`
- **Grenze:** nur beim Aufnehmen sichtbare interaktive Knoten

### `web.dom-node.link-/orders`

link:/orders ist im aufgenommenen DOM vorhanden.

- **Ceiling:** executed
- **Subjekt:** `/surface/links/0`
- **Beleg:** `surface/dom.html`
- **Falsifier:** `acceptance.web.dom-node.link-/orders`
- **Grenze:** nur beim Aufnehmen sichtbare interaktive Knoten

### `web.evidence.evidence/web-capture.json`

Die Belegdatei evidence/web-capture.json (Web-Aufnahme (vollständige Evidenz)) liegt im Paket und ist gehasht.

- **Ceiling:** statically-evidenced
- **Subjekt:** `/evidence/evidence/web-capture.json`
- **Beleg:** `evidence/web-capture.json`
- **Falsifier:** `acceptance.web.evidence.evidence/web-capture.json`

### `web.evidence.surface/dom.html`

Die Belegdatei surface/dom.html (DOM der aufgenommenen Seite) liegt im Paket und ist gehasht.

- **Ceiling:** statically-evidenced
- **Subjekt:** `/evidence/surface/dom.html`
- **Beleg:** `surface/dom.html`
- **Falsifier:** `acceptance.web.evidence.surface/dom.html`

### `web.request.get-https-//shop.test/api/orders`

GET https://shop.test/api/orders wurde während der Aufnahme aufgezeichnet.

- **Ceiling:** executed
- **Subjekt:** `/behavior/network/requests/0`
- **Beleg:** `evidence/web-capture.json`
- **Falsifier:** `acceptance.web.request.get-https-//shop.test/api/orders`
- **Grenze:** nur während der Aufnahme ausgelöste Requests

### `web.route.get-https-//shop.test/`

GET https://shop.test/ ist in der Aufnahme als geladene Seite belegt.

- **Ceiling:** statically-evidenced
- **Subjekt:** `/url`
- **Beleg:** `evidence/web-capture.json`
- **Falsifier:** `gap:route:GET https://shop.test/`
- **Grenze:** nur Ziele aufgezeichneter Schritte und statisch gefundene Routen


## 6. Abgeleitet (derived)

Aus den Beobachtungen rekonstruierte Zusammenhänge. Die Regel und die Zahl der Eingaben stehen dabei; eine Ableitung ist keine Beobachtung.

### `web.reconstruction.1.projektger-st-und-laufzeit-anlegen`

Schritt 1 (Projektgerüst und Laufzeit anlegen): Ein lauffähiges Grundprojekt mit derselben Auslieferungsform wie die Vorlage erstellen.

- **Ceiling:** executed
- **Subjekt:** `/reconstruction/0`
- **Beleg:** abgeleitet aus 2 Eingabe(n)
- **Ableitung:** Regel `reconstruction.step` aus 2 Eingabe(n)
- **Falsifier:** `gap:step:1`

### `web.reconstruction.2.oberfl-che-und-designsystem-nachbauen`

Schritt 2 (Oberfläche und Designsystem nachbauen): Landmarks, Überschriften, Navigation, Buttons, Formulare und Assets aus dem DOM übernehmen.

- **Ceiling:** executed
- **Subjekt:** `/reconstruction/1`
- **Beleg:** abgeleitet aus 2 Eingabe(n)
- **Ableitung:** Regel `reconstruction.step` aus 2 Eingabe(n)
- **Falsifier:** `gap:step:2`

### `web.reconstruction.3.routen-und-seitenzust-nde-implementieren`

Schritt 3 (Routen und Seitenzustände implementieren): Die belegten Navigationsziele und Routen als echte Seiten abbilden.

- **Ceiling:** executed
- **Subjekt:** `/reconstruction/2`
- **Beleg:** abgeleitet aus 2 Eingabe(n)
- **Ableitung:** Regel `reconstruction.step` aus 2 Eingabe(n)
- **Falsifier:** `gap:step:3`

### `web.reconstruction.4.api--und-datenzugriff-aufbauen`

Schritt 4 (API- und Datenzugriff aufbauen): Die beobachteten Endpunkte mit denselben Methoden und Nutzlastformen anbinden.

- **Ceiling:** executed
- **Subjekt:** `/reconstruction/3`
- **Beleg:** abgeleitet aus 2 Eingabe(n)
- **Ableitung:** Regel `reconstruction.step` aus 2 Eingabe(n)
- **Falsifier:** `gap:step:4`

### `web.reconstruction.5.interaktionen-events-und-speicher-bernehmen`

Schritt 5 (Interaktionen, Events und Speicher übernehmen): Klicks, Formulare und Zustandswechsel so verbinden, dass dieselben Folge-Requests und Speicherungen entstehen.

- **Ceiling:** executed
- **Subjekt:** `/reconstruction/4`
- **Beleg:** abgeleitet aus 2 Eingabe(n)
- **Ableitung:** Regel `reconstruction.step` aus 2 Eingabe(n)
- **Falsifier:** `gap:step:5`

### `web.reconstruction.6.statische-javascript-funktionen-und-aufrufe-nachziehen`

Schritt 6 (Statische JavaScript-Funktionen und Aufrufe nachziehen): Die im Analysegraph belegten Funktionen, Module und Aufrufbeziehungen in die neue Struktur übertragen.

- **Ceiling:** executed
- **Subjekt:** `/reconstruction/5`
- **Beleg:** abgeleitet aus 2 Eingabe(n)
- **Ableitung:** Regel `reconstruction.step` aus 2 Eingabe(n)
- **Falsifier:** `gap:step:6`

### `web.reconstruction.7.abgleich-mit-der-vorlage`

Schritt 7 (Abgleich mit der Vorlage): Die rekonstruierte Anwendung gegen DOM, Netzwerk und Speicher der Aufnahme prüfen.

- **Ceiling:** executed
- **Subjekt:** `/reconstruction/6`
- **Beleg:** abgeleitet aus 2 Eingabe(n)
- **Ableitung:** Regel `reconstruction.step` aus 2 Eingabe(n)
- **Falsifier:** `gap:step:7`


## 7. Angenommen (assumed)

Weder beobachtet noch abgeleitet. Jede Annahme nennt ihre Wirkung und den Schritt, der sie in eine Beobachtung überführen würde.

### `web.open-question.o1`

Welche visuelle Wirkung hat die Seite?

- **Ceiling:** inferred-only
- **Subjekt:** `/open_questions/0`
- **Beleg:** Annahme, kein direkter Beleg
- **Wirkung:** Es liegt kein Screenshot im Paket; Farben, Abstände und Zustände lassen sich daraus nicht ablesen.
- **Auflösung:** Die Web-Aufnahme mit Screenshot wiederholen oder die im DOM genannten Stylesheets übernehmen.
- **Falsifier:** `gap:open-question:O1`

### `web.open-question.o2`

Welche Funktionen und Aufrufe liegen im JavaScript?

- **Ceiling:** inferred-only
- **Subjekt:** `/open_questions/1`
- **Beleg:** Annahme, kein direkter Beleg
- **Wirkung:** Es wurde keine statische JavaScript-Evidenz in das Paket aufgenommen.
- **Auflösung:** Die Web-Analyse mit exportierten Skripten erneut ausführen.
- **Falsifier:** `gap:open-question:O2`

### `web.open-question.o3`

Welche Serverfunktionen stehen hinter den beobachteten Aufrufen?

- **Ceiling:** inferred-only
- **Subjekt:** `/open_questions/2`
- **Beleg:** Annahme, kein direkter Beleg
- **Wirkung:** Die Aufnahme belegt Methode, Pfad, Status und Antwortform der Requests. Ein lokaler Serverquellpfad wurde nicht übergeben; die serverseitigen Funktionen sind deshalb nicht belegt.
- **Auflösung:** Lokalen Projektquellcode als Quellordner übergeben und die nicht zugeordneten Endpunkte mit Testdaten und Fehlerfällen aufrufen.
- **Falsifier:** `gap:open-question:O3`


## 8. Abnahmekriterien

| Kriterium | Prüfung | Art | Fixture |
| --- | --- | --- | --- |
| Die Startseite rendert mit denselben Landmarks, Überschriften und sichtbaren Bedienelementen. | fehlt | — | — |
| Jede im Blaupausen-Dokument genannte Route ist erreichbar und rendert ohne Konsolenfehler. | fehlt | — | — |
| Die API-Aufrufe stimmen in Methode, Pfad und Statusklasse mit der Netzwerkliste überein. | fehlt | — | — |
| Formulare und Buttons lösen dieselben beobachteten Requests aus. | fehlt | — | — |
| Local Storage, Session Storage und Cookies verwenden dieselben Schlüssel und dieselbe Bedeutung. | fehlt | — | — |
| Local Storage, Session Storage und Cookies verwenden dieselben Schlüssel und dieselbe Bedeutung. | ohne Beleg (Gap im Ledger) | — | — |

5 Kriterium/Kriterien ohne Prüfung; das blockiert `complete`.

- **Nicht belegt:** Local Storage, Session Storage und Cookies verwenden dieselben Schlüssel und dieselbe Bedeutung. — Die Aufnahme enthält keinen Storage-Beleg (Cookies, Local oder Session Storage); der Check bestätigt nur, dass der Speicherzustand als Beleg vorliegt, nicht seine Schlüssel. (Gap `criterion:Local Storage, Session Storage und Cookies verwenden dieselben Schlüssel und dieselbe Bedeutung.` im Ledger)

## 9. Offene Punkte


### Vollständigkeitsprüfung

- **Status:** teilweise belegt
- **Pflichtprüfungen:** 2 von 25 erfüllt
- **Belegauflösung:** 4 von 25 Prüfpunkten mit auflösbarem Beleg
- **Lücken und offene Punkte:** 0
- **Punktzahl:** 72 %

### Prüfpunkte

- ✗ **Ziel und Bauauftrag:** Ziel: Shop (https://shop.test/); Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: BLUEPRINT.md (in diesem Lauf nicht erzeugbar) — kein Beleg
- ✗ **Rekonstruktionsplan von Anfang bis Ende:** 7 Schritte im positiven Aufbau; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: BLUEPRINT.md (in diesem Lauf nicht erzeugbar) — kein Beleg
- ✗ **Abnahmekriterien:** 5 prüfbare Kriterien; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: BLUEPRINT.md (in diesem Lauf nicht erzeugbar) — kein Beleg
- ✗ **Agentenauftrag mit Lückenliste:** Der Auftrag nennt Bauplan, Maschinenlesbarkeit und Lückenliste.; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: AGENT-PROMPT.md (in diesem Lauf nicht erzeugbar) — kein Beleg
- ✗ **Beweise mit Prüfsummen:** 4 von 4 Beweisen mit Pfad und SHA-256; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: BLUEPRINT.md (in diesem Lauf nicht erzeugbar) — kein Beleg
- ✗ **Quellcode und Ressourcen im Paket:** Quellcode war für diesen Lauf nicht aktiviert.; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: AGENT-PROMPT.md (in diesem Lauf nicht erzeugbar) — kein Beleg
- ✓ **DOM und sichtbare Oberfläche:** 174 Bytes DOM — Beleg: `surface/dom.html:1`
- ✓ **Bedienelemente und Struktur:** 3 Überschriften, Buttons, Links, Eingaben und Formulare — Beleg: `surface/dom.html`
- ✗ **Accessibility-Baum:** kein Accessibility-Baum — Beleg: `surface/accessibility.txt:1`
- ✗ **Screenshot:** kein Screenshot; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: surface/screenshot.png (kein Screenshot in der Aufnahme; ohne Pixel ist er nicht erzeugbar) — kein Beleg
- ✗ **Netzwerkaufrufe:** 1 Requests, 0 fehlgeschlagen; Beleg nicht auflösbar: Pointer nicht auflösbar: evidence/web-capture.json#/normalized_result/events/items/0 — Beleg: `evidence/web-capture.json#/normalized_result/events/items/0`
- ✗ **Events und Zustände:** 2 behaltene Events, 0 statische Bindings; Beleg nicht auflösbar: Pointer nicht auflösbar: evidence/web-capture.json#/normalized_result/events/items/0; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — Beleg: `evidence/web-capture.json#/normalized_result/events/items/0`
- ✗ **Beobachteter Ablauf:** 1 aufgezeichnete Schritte; Beleg nicht auflösbar: Pointer nicht auflösbar: evidence/web-capture.json#/normalized_result/steps/0 — Beleg: `evidence/web-capture.json#/normalized_result/steps/0`
- ✗ **Statische JavaScript-Analyse:** 0 Graphknoten; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/web-analysis.json (keine statische JavaScript-Analyse in diesem Lauf; ohne Analyse nicht erzeugbar) — kein Beleg
- ✗ **Funktionen im Innenleben:** 0 belegte Funktionen; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — kein Beleg
- ✗ **Aufrufstellen:** 0 belegte Aufrufstellen; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — kein Beleg
- ✗ **Datenverträge der Requests:** 0 Verträge, davon 0 mit JSON-Form; Beleg nicht auflösbar: Pointer nicht auflösbar: evidence/web-capture.json#/normalized_result/events/items/0; Grenze: BLUEPRINT.md (in diesem Lauf nicht erzeugbar) — Beleg: `evidence/web-capture.json#/normalized_result/events/items/0`
- ✗ **Serverfunktionen aus Quellcode:** kein lokaler Serverquellpfad übergeben; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — kein Beleg
- ✗ **Server-Handler und Signaturen:** 0 Funktionen mit Signatur aus der Quellanalyse; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — kein Beleg
- ✗ **Server-Aufrufstellen:** 0 Aufrufstellen in Routen und Helfern; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — kein Beleg
- ✗ **Server-Fehlerpfade:** 0 Fehler-/Statuspfade im Quellcode; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — kein Beleg
- ✗ **Datenverträge mit Serverquelle:** 0 von 0 Verträgen mit Route und Handler verknüpft; Beleg nicht auflösbar: Pointer nicht auflösbar: evidence/web-capture.json#/normalized_result/events/items/0; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — Beleg: `evidence/web-capture.json#/normalized_result/events/items/0`
- ✗ **Event-Bindings aus Oberfläche und JavaScript:** 0 statische Event-Bindings, 2 aufgezeichnete Events; Beleg nicht auflösbar: kein Beleg eingetragen; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — kein Beleg
- ✗ **Speicherzustand:** kein Speicherzustand — Beleg: `surface/storage.json:1`
- ✗ **Fehler- und Randfälle:** kein Fehlerstatus, 0 Fehlerereignisse, 0 fehlgeschlagene Requests, 0 Quellcode-Fehlerpfade; Beleg nicht auflösbar: Pointer nicht auflösbar: evidence/web-capture.json#/normalized_result/events/items/0; Grenze: evidence/source-analysis.json (kein Quelltext in diesem Lauf; ohne Quelle nicht erzeugbar) — Beleg: `evidence/web-capture.json#/normalized_result/events/items/0`

### Lücken

Keine Lücken im Rahmen dieser Prüfung.

### O1: Welche visuelle Wirkung hat die Seite?

**Warum offen:** Es liegt kein Screenshot im Paket; Farben, Abstände und Zustände lassen sich daraus nicht ablesen.

**So schließen:** Die Web-Aufnahme mit Screenshot wiederholen oder die im DOM genannten Stylesheets übernehmen.

### O2: Welche Funktionen und Aufrufe liegen im JavaScript?

**Warum offen:** Es wurde keine statische JavaScript-Evidenz in das Paket aufgenommen.

**So schließen:** Die Web-Analyse mit exportierten Skripten erneut ausführen.

### O3: Welche Serverfunktionen stehen hinter den beobachteten Aufrufen?

**Warum offen:** Die Aufnahme belegt Methode, Pfad, Status und Antwortform der Requests. Ein lokaler Serverquellpfad wurde nicht übergeben; die serverseitigen Funktionen sind deshalb nicht belegt.

**So schließen:** Lokalen Projektquellcode als Quellordner übergeben und die nicht zugeordneten Endpunkte mit Testdaten und Fehlerfällen aufrufen.

**Bezug:** `evidence/web-capture.json`


## 10. Beweise im Paket


### Paketbestandteile

| Datei | Inhalt |
| --- | --- |
| `BLUEPRINT.md` | Bauplan und Behauptungen (diese Datei) |
| `blueprint.json` | Dieselben Fakten maschinenlesbar |
| `AGENT-PROMPT.md` | Fertiger Auftrag für einen Coding-Agenten |
| `ledger.json` | Closure-Ledger mit Nennern und Einträgen |
| `acceptance.json` | Ausführbare Prüfungen samt Falsifier |
| `flows/flows.json` | Aufgenommene Abläufe |
| `specs/ui.md` | UI-Spec der sichtbaren Schale |
| `specs/logic.md` | Logik-Spec von Netzwerk, Routen und Modulen |
| `schemas/` | JSON-Schemas für Claims, Ledger, Manifest, Flows |
| `evidence/` | Paketinterne Belege (Aufnahme, Analyse) |
| `surface/` | DOM und weitere Oberflächenbelege |
| `MANIFEST.json` | Jede Datei mit Größe und SHA-256 |
| `README.txt` | Kurzüberblick über das Paket |

- Web-Aufnahme (vollständige Evidenz): `evidence/web-capture.json` (1208 Bytes), SHA-256 `2623cf99b00efff3902e38296aa6bb1c672a8127c58edc3c8f603d5b7ce454e0`
- Accessibility-Umriss (aus dem DOM abgeleitet): `surface/accessibility.txt` (447 Bytes), SHA-256 `adefaa98abe6edfa17ac0ffb093ca50620460c516cd5787ecfc14a3d1e7b8188`
- DOM der aufgenommenen Seite: `surface/dom.html` (174 Bytes), SHA-256 `b4ca0fe6050f4919306fd4ad60fe538795a9e940b975a62445593ae2e80ded1c`
- Speicherzustand (keine Storage-Daten in der Aufnahme): `surface/storage.json` (282 Bytes), SHA-256 `dc1418a25b09d8b559e9e3d3897876d9bd7edfeb4b7889be8063db18958f0271`

### Nicht erzeugbare Belege (geprüft an der Aufnahme)

| Beleg | Warum nicht erzeugbar | Fehlt in der Aufnahme | Vorhandene Schlüssel |
| --- | --- | --- | --- |
| evidence/web-analysis.json (nicht im Paket) | Die Aufnahme enthält keinen Skript- oder Quelltext (keine Body-/Content-/Source-Felder mit JavaScript), daher ist keine statische Analyse erzeugbar. | Skript-Body oder Quelltext in events.items/artifacts | capture_keys=["completeness","events","final_url","steps","url"], step_artifacts=["dom"], event_keys=["kind","method","resource_type","sequence","status","transaction_id","url"] |
| evidence/source-analysis.json (nicht im Paket) | Ohne Skript- oder Quelltext ist auch die Quellanalyse (Routen, Funktionen, Aufrufe) nicht erzeugbar. | source/web/**, Skript-Body | capture_keys=["completeness","events","final_url","steps","url"], step_artifacts=["dom"] |
| surface/screenshot.png (nicht im Paket) | Die Aufnahme enthält kein Screenshot-Artefakt; ohne Pixel ist kein Bild erzeugbar. | steps[*].artifacts.screenshot | step_artifacts=["dom"] |


### Behauptungen und ihre Belege

| Behauptung | Art | Ceiling | Beleg | Falsifier |
| --- | --- | --- | --- | --- |
| `web.dom-node.button-buy` | observed | executed | `surface/dom.html` | `acceptance.web.dom-node.button-buy` |
| `web.dom-node.link-/orders` | observed | executed | `surface/dom.html` | `acceptance.web.dom-node.link-/orders` |
| `web.evidence.evidence/web-capture.json` | observed | statically-evidenced | `evidence/web-capture.json` | `acceptance.web.evidence.evidence/web-capture.json` |
| `web.evidence.surface/dom.html` | observed | statically-evidenced | `surface/dom.html` | `acceptance.web.evidence.surface/dom.html` |
| `web.open-question.o1` | assumed | inferred-only | Annahme | `gap:open-question:O1` |
| `web.open-question.o2` | assumed | inferred-only | Annahme | `gap:open-question:O2` |
| `web.open-question.o3` | assumed | inferred-only | Annahme | `gap:open-question:O3` |
| `web.reconstruction.1.projektger-st-und-laufzeit-anlegen` | derived | executed | abgeleitet aus 2 Eingabe(n) | `gap:step:1` |
| `web.reconstruction.2.oberfl-che-und-designsystem-nachbauen` | derived | executed | abgeleitet aus 2 Eingabe(n) | `gap:step:2` |
| `web.reconstruction.3.routen-und-seitenzust-nde-implementieren` | derived | executed | abgeleitet aus 2 Eingabe(n) | `gap:step:3` |
| `web.reconstruction.4.api--und-datenzugriff-aufbauen` | derived | executed | abgeleitet aus 2 Eingabe(n) | `gap:step:4` |
| `web.reconstruction.5.interaktionen-events-und-speicher-bernehmen` | derived | executed | abgeleitet aus 2 Eingabe(n) | `gap:step:5` |
| `web.reconstruction.6.statische-javascript-funktionen-und-aufrufe-nachziehen` | derived | executed | abgeleitet aus 2 Eingabe(n) | `gap:step:6` |
| `web.reconstruction.7.abgleich-mit-der-vorlage` | derived | executed | abgeleitet aus 2 Eingabe(n) | `gap:step:7` |
| `web.request.get-https-//shop.test/api/orders` | observed | executed | `evidence/web-capture.json` | `acceptance.web.request.get-https-//shop.test/api/orders` |
| `web.route.get-https-//shop.test/` | observed | statically-evidenced | `evidence/web-capture.json` | `gap:route:GET https://shop.test/` |
