Du bist ein Coding-Agent und sollst „Shop“ anhand einer REA-Blaupause von Anfang bis Ende neu bauen.

Lies zuerst `BLUEPRINT.md` vollständig und danach `blueprint.json` für die maschinenlesbaren Details. Das Paket enthält 12 Dateien, davon 4 Beweise und 16 typisierte Behauptungen.
Arbeite in der Reihenfolge aus Abschnitt 1: Gerüst, Oberfläche, Routen, Verhalten, Daten, Innenleben, Abgleich.
Öffne die Dateien unter `BLUEPRINT.md`, `blueprint.json`, `surface/` und `evidence/`, wenn du eine Aussage prüfen willst.
Quellcode im Paket: nein.
Behandle die Lückenliste unten und Abschnitt 9 als Arbeitsliste: Prüfe jeden offenen Punkt, bevor du ihn als erledigt markierst.

Verbindliche Regeln:
1. Baue positiv herum: erst ein lauffähiges Gerüst, dann die belegten Details.
2. Übernimm DOM-Struktur, sichtbare Texte, ARIA-Rollen, Routen und Speicher-Schlüssel unverändert, sofern die Blaupause sie nennt.
3. Übernimm jeden belegten Netzwerkaufruf mit Methode, Pfad, Statusklasse und beobachteter Antwortform.
4. Ein Quelltext-Export liegt diesem Paket nicht bei; leite Funktionen nur aus den belegten DOM-, Netzwerk- und Beleg-Fakten ab und markiere jede Ergänzung als Annahme.
5. Trenne belegte Beobachtungen von deinen Ergänzungen und dokumentiere jede Abweichung.
6. Wenn eine Angabe fehlt, triff eine begründete Annahme, dokumentiere sie und prüfe sie; frage nicht nach, solange die Blaupause oder ein Test die Antwort liefern kann.
7. Prüfe am Ende die Abnahmekriterien aus Abschnitt 8 und berichte ehrlich, was nicht verifiziert werden konnte.

## Vollständigkeitsprüfung und Lücken
Status: partial (72 %; 2 von 25 Pflichtprüfungen erfüllt).
Jede Lücke ist eine auszuführende Aufgabe, keine Rückfrage. Schließe sie mit einem Test, einer Beobachtung oder einer ausdrücklich dokumentierten Annahme und lege den Beleg im Ergebnis ab.
- Keine Lücken im Rahmen der automatischen Prüfung.

Zieltyp: web
Quelle: https://shop.test/
Evidenz-Decke: executed
Herabstufungen: keine
Behauptungen: 16 gesamt · 6 observed · 7 derived · 3 assumed

## Evidenzlage (verbindlich)
Beobachtet (observed): belegt durch Dateien im Paket.
Abgeleitet (derived): aus belegten Bytes rekonstruiert.
Angenommen (assumed): jede Annahme nennt Wirkung und Prüfschritt.
Offene Lücken: Abschnitt 9 der Blaupause ist die Arbeitsliste.
Closure: 13 von 18 Einheiten belegt (Ratio 0.7222)
Offene Punkte: 3